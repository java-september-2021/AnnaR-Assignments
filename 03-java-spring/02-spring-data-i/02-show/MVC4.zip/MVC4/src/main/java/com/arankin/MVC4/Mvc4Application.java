package com.arankin.MVC4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mvc4Application {

	public static void main(String[] args) {
		SpringApplication.run(Mvc4Application.class, args);
	}

}
