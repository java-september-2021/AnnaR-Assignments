package com.arankin.MVC4.Models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity  //This entity means this is related to a database
@Table(name="books")
public class Book {

	@Id //Means the primary key will be auto-generated.
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
   
	@NotNull
    @Size(min = 5, max = 200)
    private String title;
   
	@NotNull
    @Size(min = 5, max = 200)
    private String description;
   
	@NotNull
    @Size(min = 3, max = 40)
    private String language;
   
	@NotNull
    @Min(50)
    private Integer numberOfPages;
    
    // This will not allow the createdAt column to be updated after creation
    @Column(updatable=false) //This is to ensure data is not updated every time the object is created
    
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date createdAt;
   
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date updatedAt;


    //--------------------  
    //Constructors
    //-------------------        
    public Book() {
    }
    
    public Book(String title, String desc, String lang, int pages) {
        this.title = title;
        this.description = desc;
        this.language = lang;
        this.numberOfPages = pages;
    }
    
    
    @PrePersist
    protected void onCreate(){
        this.createdAt = new Date();
    }
    @PreUpdate
    protected void onUpdate(){
        this.updatedAt = new Date();
    }
    
    //--------------------  
    //getters and setters
    //-------------------
	public Long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getLanguage() {
		return language;
	}

	public Integer getNumberOfPages() {
		return numberOfPages;
	}
	
	public Date getCreatedAt() {
		return createdAt;
	}	
	public Date getUpdatedAt() {
		return updatedAt;
	}
	 
	public void setId(Long id) {
		this.id = id;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setLanguage(String language) {
		this.language = language;
	}	
	public void setNumberOfPages(Integer numberOfPages) {
		this.numberOfPages = numberOfPages;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
    public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}   
	
}//Book
