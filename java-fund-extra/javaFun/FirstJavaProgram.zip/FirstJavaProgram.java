
public class FirstJavaProgram{
    public static void main(String[] args) {
        System.out.println("My name is Anna Rankin");
        System.out.println("I am 100 (minus some change) years old");
        System.out.println("My hometown is Rochester, NY");
    }
}